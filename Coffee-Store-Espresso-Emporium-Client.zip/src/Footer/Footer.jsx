import React from "react";
import {
  FaFacebookF,
  FaTwitter,
  FaInstagram,
  FaLinkedinIn,
  FaPhoneAlt,
} from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { FaLocationDot } from "react-icons/fa6";
import logo from "../assets/images/more/logo1.png"
import Container from "../Container/Container";

const Footer = () => {
  return (
    <Container>
      <footer className="py-16 px-10">
        <div className=" grid md:grid-cols-2 gap-12">
          {/* ---------- Left Section ---------- */}
          <div>
            {/* Logo */}
            <img src={logo} className="w-16 h-16 mb-4" alt="logo" />

            <h2 className="text-3xl font-bold font-serif text-[#3c2f2f]">
              Espresso Emporium
            </h2>

            <p className="mt-4 text-gray-700 leading-relaxed">
              Always ready to be your friend. Come & Contact with us to share
              your memorable moments, to share with your best companion.
            </p>

            {/* Social Icons */}
            <div className="flex gap-4 mt-6 text-xl">
              <FaFacebookF className="cursor-pointer hover:text-[#3c2f2f]" />
              <FaTwitter className="cursor-pointer hover:text-[#3c2f2f]" />
              <FaInstagram className="cursor-pointer hover:text-[#3c2f2f]" />
              <FaLinkedinIn className="cursor-pointer hover:text-[#3c2f2f]" />
            </div>

            {/* Contact */}
            <h3 className="text-2xl mt-8 font-serif font-bold text-[#3c2f2f]">
              Get in Touch
            </h3>

            <div className="mt-4 space-y-3 text-gray-700">
              <p className="flex items-center gap-3">
                <FaPhoneAlt className="text-lg" /> +88 01533 333 333
              </p>
              <p className="flex items-center gap-3">
                <MdEmail className="text-xl" /> info@gmail.com
              </p>
              <p className="flex items-center gap-3">
                <FaLocationDot className="text-xl" /> 72, Wall street, King
                Road, Dhaka
              </p>
            </div>
          </div>

          {/* ---------- Right Section ---------- */}
          <div>
            <h2 className="text-3xl font-bold font-serif text-[#3c2f2f] mb-6">
              Connect with Us
            </h2>

            <form className="space-y-4">
              <input
                type="text"
                placeholder="Name"
                className="w-full bg-white border border-gray-200 px-4 py-3 rounded-md focus:outline-none focus:border-[#3c2f2f]"
              />

              <input
                type="email"
                placeholder="Email"
                className="w-full bg-white border border-gray-200 px-4 py-3 rounded-md focus:outline-none focus:border-[#3c2f2f]"
              />

              <textarea
                rows="5"
                placeholder="Message"
                className="w-full bg-white border border-gray-200 px-4 py-3 rounded-md resize-none focus:outline-none focus:border-[#3c2f2f]"
              ></textarea>

              <button
                type="submit"
                className="px-6 cursor-pointer py-2 border-2 border-[#3c2f2f] text-[#3c2f2f] rounded-full hover:bg-[#3c2f2f] hover:text-white transition font-medium"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </footer>
    </Container>
  );
};

export default Footer;
